package com.example.SpringBootCRUD.model;

import jakarta.persistence.*;


@Entity
@Table(name = "member")
public class Book {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)



    
    private Long id;

    @SuppressWarnings("unused")
	private String title;

	@SuppressWarnings("unused")
	private String author;
  
    public Object getTitle() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getAuthor() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setAuthor(Object author2) {
		// TODO Auto-generated method stub
		
	}
	public Object getIsbn() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setTitle(Object title2) {
		// TODO Auto-generated method stub
		
	}
	public void setIsbn(Object isbn2) {
		// TODO Auto-generated method stub
		
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
}
