package com.example.SpringBootCRUD.services;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.SpringBootCRUD.model.Book;
import com.example.SpringBootCRUD.repositary.BookRepositary;

import jakarta.annotation.Nullable;

import org.springframework.data.jpa.repository.JpaRepository;
@SuppressWarnings("unused")
@Service
public class BookService {

   
	 private BookRepositary bookRepository;
    // Constructor injection
    public BookService(BookRepositary bookRepository) {
        this.bookRepository = bookRepository;
    }

    // CREATE and UPDATE (via JpaRepository's save() method)
    public Book saveBook(Book book) {
        // Here you would add validation logic (e.g., ensure Title/Author are not empty)
        // Note: The ISBN uniqueness is handled by the @Column(unique = true) in the Book Entity
        return bookRepository.save(book);
    }

//    // READ (Public/Member Search)
//    public interface BookRepositary extends JpaRepository<Book, Long> {
//
//List<Book> searchBooks(String query);
//}
//   // READ (Admin: Get all books)
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }
    
    // READ (Get a single book by ID)
    public Optional<Book> getBookById(Long id) {
        return bookRepository.findById(id);
    }

    // DELETE
    public void deleteBook(Long id) {
        // Logic to ensure the book is not currently on loan before deleting
        if (bookRepository.existsById(id)) {
            bookRepository.deleteById(id);
        } else {
        	//Delete
        }
        	
    }

	public @Nullable Object getBooksByQuery(Object string) {
		// TODO Auto-generated method stub
		return null;
	}
}