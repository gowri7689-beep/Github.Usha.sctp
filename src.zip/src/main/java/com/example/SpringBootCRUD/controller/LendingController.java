package com.example.SpringBootCRUD.controller;

import com.example.SpringBootCRUD.model.Lending;
import com.example.SpringBootCRUD.services.LendingService;

import io.micrometer.common.lang.Nullable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/lendings")

public class LendingController {

	private final LendingService lendingService=null;

    @PostMapping
    public ResponseEntity<Lending> createLending(@RequestBody Lending 
    		record) {
    		return ResponseEntity.ok(lendingService.createLending(record));
    }

    @GetMapping("/{id}")
    public ResponseEntity<Lending> getLending(@PathVariable Long id) {
    	return ResponseEntity.ok(lendingService.getLendingById(id));
    }

    @GetMapping
    public @Nullable Object getAllLendings() {
    	// TODO Auto-generated method stub
    	return null;
    	}
    

    @PutMapping("/{id}")
    public @Nullable Object updateLending(Long id2, Lending updatedRecord) {
    	// TODO Auto-generated method stub
    	return null;
    	}
    	
    @DeleteMapping("/{id}")
    public void deleteLending(Long id2) {
    	// TODO Auto-generated method stub

    } 
    
    @GetMapping("/member/{memberId}")
    public ResponseEntity<Object> getByMember(@PathVariable Long 
    		memberId) {
    return ResponseEntity.ok(lendingService.getLendingById(memberId));
    }

    @GetMapping("/book/{bookId}")
    public ResponseEntity<Object> getByBook(@PathVariable Long 
    bookId) {
    return ResponseEntity.ok(lendingService.getLendingsByBook(bookId));
    }
    }

