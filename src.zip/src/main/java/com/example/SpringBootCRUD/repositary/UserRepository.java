package com.example.SpringBootCRUD.repositary;

import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	<S> com.example.SpringBootCRUD.model.User saveAll(S user);

	

}
