package com.example.SpringBootCRUD.services;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringBootCRUD.model.Member;
import com.example.SpringBootCRUD.repositary.MemberRepository;


@Service
public class MemberService {
	

	    @Autowired
	    private MemberRepository memberRepository;

	    // Create
	    public Member saveMember(Member member) {
	        return memberRepository.save(member);
	    }

	    // Read all
	    public List<Member> getAllMembers() {
	        return memberRepository.findAll();
	    }

	    // Read by ID
	    public Optional<Member> getMemberById(Long id) {
	        return memberRepository.findById(id);
	    }

	    // Update
	    public Member updateMember(Long id, Member memberDetails) {
	        Member member = memberRepository.findById(id).orElseThrow();

	        member.setFirstName(memberDetails.getFirstName());
	        member.setLastName(memberDetails.getLastName());
	        member.setEmail(memberDetails.getEmail());
	        member.setPhone(memberDetails.getPhone());
	        member.setAddress(memberDetails.getAddress());

	        return memberRepository.save(member);
	    }

	    // Delete
	    public void deleteMember(Long id) {
	        memberRepository.deleteById(id);
	    }
	}