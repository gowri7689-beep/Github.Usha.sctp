package com.example.SpringBootCRUD.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.SpringBootCRUD.model.User;
import com.example.SpringBootCRUD.services.UserService;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")  // React connection
@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService service;

    /* ----------------- GET ALL ---------------- */
    @GetMapping
    public List<org.springframework.boot.autoconfigure.security.SecurityProperties.User> getAll() {
        return service.getAllUsers();
    }

    /* ----------------- GET BY ID ---------------- */
    @GetMapping("/{id}")
    public ResponseEntity<org.springframework.boot.autoconfigure.security.SecurityProperties.User> getOne(@PathVariable Long id) {
        org.springframework.boot.autoconfigure.security.SecurityProperties.User user = service.getUserById(id);
        return (user != null)
                ? ResponseEntity.ok(user)
                : ResponseEntity.notFound().build();
    }

    /* ----------------- ADD USER ---------------- */
    @PostMapping
    public ResponseEntity<Boolean> add(@RequestBody Long user) {
        return ResponseEntity.ok(service.deleteUser(user));
    }

    /* ----------------- UPDATE USER ---------------- */
    @PutMapping("/{id}")
    public ResponseEntity<org.springframework.boot.autoconfigure.security.SecurityProperties.User> update(
            @PathVariable Long id,
            @RequestBody User userData) {

        org.springframework.boot.autoconfigure.security.SecurityProperties.User updated = service.updateUser(id, userData);

        return (updated != null)
                ? ResponseEntity.ok(updated)
                : ResponseEntity.notFound().build();
    }

    /* ----------------- DELETE USER ---------------- */
    @DeleteMapping("/{id}")
    public ResponseEntity<String> delete(@PathVariable Long id) {
        boolean deleted = service.deleteUser(id);

        return deleted
                ? ResponseEntity.ok("User deleted")
                : ResponseEntity.notFound().build();
    }
}
