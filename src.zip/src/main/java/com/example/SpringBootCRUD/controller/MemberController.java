package com.example.SpringBootCRUD.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringBootCRUD.model.Member;
import com.example.SpringBootCRUD.services.MemberService;



@RestController
@RequestMapping("/api/members")

@CrossOrigin(origins = "http://localhost:3000") // allow React dev server
public class MemberController {
	 @Autowired
	    private MemberService memberService;

	    // Create a new member
	    @PostMapping("/addMember")
	    public Member createMember(@RequestBody Member member) {
	        return memberService.saveMember(member);
	    }

	    // Get all members
	    @GetMapping("/allMember")
	    public List<Member> getAllMembers() {
	        return memberService.getAllMembers();
	    }

	    // Get member by ID
	    @GetMapping("/{id}")
	    public ResponseEntity<Member> getMemberById(@PathVariable Long id) {
	        Member member = memberService.getMemberById(id)
	                .orElseThrow();
	        return ResponseEntity.ok(member);
	    }

	    // Update member
	    @PutMapping("/{id}")
	    public ResponseEntity<Member> updateMember(
	            @PathVariable Long id,
	            @RequestBody Member memberDetails) {
	        Member updatedMember = memberService.updateMember(id, memberDetails);
	        return ResponseEntity.ok(updatedMember);
	    }

	    // Delete member
	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteMember(@PathVariable Long id) {
	        memberService.deleteMember(id);
	        return ResponseEntity.noContent().build();
	    }
}

    