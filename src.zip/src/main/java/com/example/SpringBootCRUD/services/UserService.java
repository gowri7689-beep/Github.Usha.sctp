package com.example.SpringBootCRUD.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringBootCRUD.model.User;
import com.example.SpringBootCRUD.repositary.UserRepository;

import java.util.List;

@Service
public class UserService {

    @Autowired
    private UserRepository repo;

    public List<org.springframework.boot.autoconfigure.security.SecurityProperties.User> getAllUsers() {
        return repo.findAll();
    }

    public org.springframework.boot.autoconfigure.security.SecurityProperties.User getUserById(Long id) {
        return repo.findById(id).orElse(null);
    }

    public <S> User saveUser(User user) {
        return repo.saveAll((S) user);
    }

    private void setEmail(String email) {
    	// TODO Auto-generated method stub

    	}

    public boolean deleteUser(Long id) {
        if (repo.existsById(id)) {
            repo.deleteById(id);
            return true;
        }
        return false;
    }

	public org.springframework.boot.autoconfigure.security.SecurityProperties.User updateUser1(Long id, User userData) {
		// TODO Auto-generated method stub
		return null;
	}

	public org.springframework.boot.autoconfigure.security.SecurityProperties.User updateUser11(Long id, User userData) {
		// TODO Auto-generated method stub
		return null;
	}

	public org.springframework.boot.autoconfigure.security.SecurityProperties.User updateUser(Long id, User userData) {
		// TODO Auto-generated method stub
		return null;
	}
}

