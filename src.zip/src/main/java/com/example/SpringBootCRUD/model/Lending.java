package com.example.SpringBootCRUD.model;

import java.time.LocalDate;

import jakarta.annotation.Nullable;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity

public class Lending {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Member member;

    @ManyToOne
    private Book book;

    private LocalDate Borrowdate;
    private LocalDate dueDate;
    private LocalDate returnDate;

    private double fineAmount;

	public LocalDate getDueDate() {
		return dueDate;
	}

	public void setDueDate(LocalDate dueDate) {
		this.dueDate = dueDate;
	}

	public LocalDate getBorrowdate() {
		return Borrowdate;
	}

	public void setBorrowdate(LocalDate borrowdate) {
		Borrowdate = borrowdate;
	}

	public LocalDate getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(LocalDate returnDate) {
		this.returnDate = returnDate;
	}

	public double getFineAmount() {
		return fineAmount;
	}

	public void setFineAmount(double fineAmount) {
		this.fineAmount = fineAmount;
	}

	public @Nullable Object getLendingById(Long id2) {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getLendingsByBook(Long bookId) {
		// TODO Auto-generated method stub
		return null;
	}
}
