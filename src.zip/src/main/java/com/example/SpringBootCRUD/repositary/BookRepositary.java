package com.example.SpringBootCRUD.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SpringBootCRUD.model.Book;


public interface BookRepositary extends JpaRepository<Book, Long> {
}
