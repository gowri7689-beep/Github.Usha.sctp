package com.example.SpringBootCRUD.services;


import java.util.List;
import java.util.Optional;

import com.example.SpringBootCRUD.model.Lending;

public interface LendingService {

	Lending createLending(Lending record);

    Lending getLendingById(Long id);

    List<Lending> getAllLendings();

    Lending updateLending(Long id, Lending updatedRecord);

    void deleteLending(Long id);

    List<Lending> getLendingsByMember(Long memberId);

    Optional<Lending> getLendingsByBook(Long bookId);
}
