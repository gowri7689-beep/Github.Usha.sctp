package com.example.SpringBootCRUD.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SpringBootCRUD.model.Member;
import com.example.SpringBootCRUD.repositary.MemberRepository;


@Service
public class MemberServiceImpl  
{

//    @Autowired
//    private MemberRepository memberRepository;
//
//   
//    public Member saveMember(Member member) {
//        return memberRepository.save(member);
//    }
//
//   
//    public List<Member> getAllMembers() {
//        return memberRepository.findAll();
//    }
//
//    public Optional<Member> getMemberById(Long id) {
//        return memberRepository.findById(id);
//    }
//
//    public Member updateMember(Long id, Member memberDetails) {
//        Member existingMember = memberRepository.findById(id)
//                .orElseThrow(() -> new RuntimeException("Member not found with id: " + id));
//
//        existingMember.setFirstName(memberDetails.getFirstName());
//        existingMember.setLastName(memberDetails.getLastName());
//        existingMember.setEmail(memberDetails.getEmail());
//        existingMember.setPhone(memberDetails.getPhone());
//        existingMember.setAddress(memberDetails.getAddress());
//
//        return memberRepository.save(existingMember);
//    }
//
//   
//    public void deleteMember(Long id) {
//        Member member = memberRepository.findById(id)
//                .orElseThrow(() -> new RuntimeException("Member not found with id: " + id));
//
//        memberRepository.delete(member);
//    }
}
