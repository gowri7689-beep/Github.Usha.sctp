package com.example.SpringBootCRUD.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SpringBootCRUD.model.Lending;



public interface LendingRepository extends JpaRepository<Lending, Long> {
}
